# AnimeRaven Android — Categories Update 🐦

This version adds a dedicated **Categories** tab with:

- ⚔️ Action
- 😂 Comedy
- ❤️ Romance
- 🧙 Fantasy
- 🗺️ Adventure
- 🎭 Drama
- 🕵️ Mystery
- 🚀 Sci-Fi
- 🏆 Sports
- 👻 Supernatural

Tap a category to load its anime list from Jikan. Favorites remain available from the Favorites tab.

## Build
Open the project in Android Studio, sync Gradle, then use:

**Build → Build App Bundle(s) / APK(s) → Build APK(s)**

The debug APK is normally created at:
`app/build/outputs/apk/debug/app-debug.apk`
