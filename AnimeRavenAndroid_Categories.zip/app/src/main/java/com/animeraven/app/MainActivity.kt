package com.animeraven.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import kotlin.random.Random

data class Anime(
    val mal_id: Int,
    val title: String,
    val score: Double?,
    val episodes: Int?,
    val status: String?,
    val synopsis: String?,
    val images: Images?
)
data class Images(val jpg: Jpg?)
data class Jpg(val large_image_url: String?, val image_url: String?)
data class AnimeResponse(val data: List<Anime>, val pagination: Pagination?)
data class Pagination(val has_next_page: Boolean?)

interface JikanApi {
    @GET("anime")
    suspend fun anime(
        @Query("genres") genres: Int? = null,
        @Query("q") query: String? = null,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 24,
        @Query("sfw") sfw: Boolean = true
    ): AnimeResponse
}

object Api {
    val service: JikanApi = Retrofit.Builder()
        .baseUrl("https://api.jikan.moe/v4/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(JikanApi::class.java)
}

val genres = linkedMapOf(
    "Action" to 1, "Comedy" to 4, "Romance" to 22, "Fantasy" to 10,
    "Adventure" to 2, "Drama" to 8, "Mystery" to 7, "Sci-Fi" to 24,
    "Sports" to 30, "Supernatural" to 37
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeRavenApp() }
    }
}

@Composable
fun AnimeRavenApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9B6CFF),
            secondary = Color(0xFFBCA7FF),
            background = Color(0xFF080B16),
            surface = Color(0xFF12172A)
        )
    ) {
        var tab by remember { mutableIntStateOf(0) }
        var favorites by remember { mutableStateOf(listOf<Anime>()) }
        val scope = rememberCoroutineScope()
        var selectedGenre by remember { mutableStateOf("Action") }
        var picks by remember { mutableStateOf(listOf<Anime>()) }
        var categoryAnime by remember { mutableStateOf(listOf<Anime>()) }
        var search by remember { mutableStateOf("") }
        var searchResults by remember { mutableStateOf(listOf<Anime>()) }
        var loading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }

        fun loadGenre(randomize: Boolean = true) {
            scope.launch {
                loading = true; error = null
                try {
                    val list = Api.service.anime(genres[selectedGenre], limit = 24).data
                    picks = if (randomize) list.shuffled(Random(System.currentTimeMillis())).take(6) else list
                } catch (e: Exception) {
                    error = "Couldn't load anime. Check your internet connection."
                }
                loading = false
            }
        }

        fun loadCategory(name: String) {
            selectedGenre = name
            scope.launch {
                loading = true; error = null
                try {
                    categoryAnime = Api.service.anime(genres[name], limit = 24).data
                    tab = 1
                } catch (e: Exception) {
                    error = "Couldn't load this category."
                }
                loading = false
            }
        }

        fun doSearch() {
            if (search.isBlank()) return
            scope.launch {
                loading = true; error = null
                try { searchResults = Api.service.anime(q = search.trim(), limit = 24).data }
                catch (e: Exception) { error = "Search failed. Try again." }
                loading = false
            }
        }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Text("🏠") }, label = { Text("Home") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Text("📚") }, label = { Text("Categories") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Text("🔎") }, label = { Text("Search") })
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = { Text("❤️") }, label = { Text("Favorites") })
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(Color(0xFF080B16))
            ) {
                Text("🐦 AnimeRaven", modifier = Modifier.padding(20.dp), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 20.dp)) }

                when (tab) {
                    0 -> HomeScreen(selectedGenre, { selectedGenre = it }, picks, loading, { loadGenre() }, favorites) {
                        anime -> if (!favorites.any { it.mal_id == anime.mal_id }) favorites = favorites + anime
                    }
                    1 -> CategoriesScreen(
                        selectedGenre, genres.keys.toList(), categoryAnime, loading,
                        { loadCategory(it) }, favorites
                    ) { anime ->
                        if (!favorites.any { it.mal_id == anime.mal_id }) favorites = favorites + anime
                    }
                    2 -> SearchScreen(search, { search = it }, searchResults, loading, { doSearch() }, favorites) {
                        anime -> if (!favorites.any { it.mal_id == anime.mal_id }) favorites = favorites + anime
                    }
                    3 -> AnimeGrid(categoryAnime = favorites, favorites = favorites,
                        action = { anime -> favorites = favorites.filterNot { it.mal_id == anime.mal_id } },
                        empty = "No favorites yet.")
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    genre: String, onGenre: (String) -> Unit, picks: List<Anime>, loading: Boolean,
    onPick: () -> Unit, favorites: List<Anime>, onFavorite: (Anime) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("🎲 Raven Picks", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }) { Text(genre) }
                DropdownMenu(expanded, { expanded = false }) {
                    genres.keys.forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { onGenre(it); expanded = false })
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Button(onClick = onPick, enabled = !loading) { Text(if (loading) "Loading..." else "🎲 Pick") }
        }
        Spacer(Modifier.height(14.dp))
        if (picks.isEmpty() && !loading) Text("Pick a genre and tap Pick to discover anime.", color = Color.LightGray)
        else AnimeGrid(picks, favorites, onFavorite, "No anime found.")
    }
}

@Composable
fun CategoriesScreen(
    selected: String, categoryNames: List<String>, anime: List<Anime>, loading: Boolean,
    onCategory: (String) -> Unit, favorites: List<Anime>, onFavorite: (Anime) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("📚 Categories", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Choose a genre to browse anime.", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(170.dp)
        ) {
            items(categoryNames) { name ->
                val icon = when (name) {
                    "Action" -> "⚔️"; "Comedy" -> "😂"; "Romance" -> "❤️"
                    "Fantasy" -> "🧙"; "Adventure" -> "🗺️"; "Drama" -> "🎭"
                    "Mystery" -> "🕵️"; "Sci-Fi" -> "🚀"; "Sports" -> "🏆"
                    else -> "👻"
                }
                Card(
                    modifier = Modifier.clickable { onCategory(name) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (name == selected) Color(0xFF2A2147) else Color(0xFF12172A)
                    )
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("$icon  $name", fontWeight = FontWeight.Bold)
                        Text("Browse $name", fontSize = 12.sp, color = Color.LightGray)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("🔥 $selected Anime", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        if (loading) CircularProgressIndicator()
        else AnimeGrid(anime, favorites, onFavorite, "Tap a category above.")
    }
}

@Composable
fun SearchScreen(
    search: String, onSearch: (String) -> Unit, results: List<Anime>, loading: Boolean,
    onSearchClick: () -> Unit, favorites: List<Anime>, onFavorite: (Anime) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(search, onSearch, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Search anime...") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = onSearchClick) { Text("Go") }
        }
        Spacer(Modifier.height(14.dp))
        if (loading) CircularProgressIndicator()
        else AnimeGrid(results, favorites, onFavorite, "Search for an anime above.")
    }
}

@Composable
fun AnimeGrid(
    categoryAnime: List<Anime>, favorites: List<Anime>, action: (Anime) -> Unit, empty: String
) {
    if (categoryAnime.isEmpty()) {
        Text(empty, color = Color.LightGray)
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        items(categoryAnime, key = { it.mal_id }) { item ->
            Card {
                Column(Modifier.padding(8.dp)) {
                    AsyncImage(
                        model = item.images?.jpg?.large_image_url ?: item.images?.jpg?.image_url,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxWidth().height(220.dp),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(item.title, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("⭐ ${item.score ?: "N/A"}  •  ${item.episodes ?: "?"} eps", fontSize = 12.sp, color = Color.LightGray)
                    Text(item.status ?: "Unknown", fontSize = 12.sp, color = Color.LightGray)
                    val saved = favorites.any { it.mal_id == item.mal_id }
                    Text(
                        if (saved) "❤️ Saved" else "♡ Favorite",
                        modifier = Modifier.padding(top = 7.dp).clickable {
                            action(item)
                        },
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
